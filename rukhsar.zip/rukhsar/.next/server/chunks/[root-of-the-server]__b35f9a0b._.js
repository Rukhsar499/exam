module.exports = [
"[project]/.next-internal/server/app/api/easebuzz-callback/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/api/easebuzz-callback/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
async function POST(req) {
    try {
        // Get form or URL-encoded data safely
        let entries = {};
        try {
            const data = await req.formData();
            entries = Object.fromEntries(data.entries());
        } catch  {
            const body = await req.text();
            entries = Object.fromEntries(new URLSearchParams(body));
        }
        console.log("Easebuzz Callback Data:", entries);
        // Send callback to backend
        const res = await fetch("https://njportal.thenoncoders.in/api/v1/confirm_payment_ezb", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": ("TURBOPACK compile-time value", "x908707x7f0c36aedab814b9ceb0390cef342dc193a87795_D15C968A8C79A09506AC733AA7B9FDD8AC44552B91F7B6") || ""
            },
            body: JSON.stringify(entries)
        });
        const backendResponse = await res.json();
        console.log("Backend Response:", backendResponse);
        const txnid = entries.txnid || backendResponse?.data?.txnid || "";
        const paymentstatus = entries.payment_status || entries.status || entries.easepay_status || backendResponse?.data?.payment_status || "failed";
        const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000")?.trim() || "http://localhost:3000";
        const redirectUrl = paymentstatus.toLowerCase() === "success" ? `${baseUrl}/payment-success` : `${baseUrl}/payment-failed`;
        console.log("➡️ Redirecting to:", redirectUrl);
        return new Response(null, {
            status: 302,
            headers: {
                Location: redirectUrl
            }
        });
    } catch (err) {
        console.error("🔥 Error in Easebuzz Callback:", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "callback error"
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b35f9a0b._.js.map