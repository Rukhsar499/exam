(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0da25092._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_7b5eda4c._.js"
],
    source: "dynamic"
});
