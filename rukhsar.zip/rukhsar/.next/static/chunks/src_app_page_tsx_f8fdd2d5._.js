(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_29ced537._.js",
  "static/chunks/src_app_components_Header_tsx_4c82d3af._.js"
],
    source: "dynamic"
});
