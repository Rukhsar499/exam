(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_57d40746._.js",
  "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_a9cb0712.js",
  "static/chunks/node_modules_next_dist_compiled_5150ccfd._.js",
  "static/chunks/node_modules_next_dist_client_cf1d9188._.js",
  "static/chunks/node_modules_next_dist_b0daae9a._.js",
  "static/chunks/node_modules_@swc_helpers_cjs_b3dc30d6._.js"
],
    source: "entry"
});
