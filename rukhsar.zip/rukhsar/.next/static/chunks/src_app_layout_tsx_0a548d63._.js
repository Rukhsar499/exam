(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_ff5d7e3a._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_b69a7a67._.js",
  "static/chunks/[root-of-the-server]__1dff1260._.js",
  "static/chunks/[root-of-the-server]__567f9b33._.css"
],
    source: "dynamic"
});
